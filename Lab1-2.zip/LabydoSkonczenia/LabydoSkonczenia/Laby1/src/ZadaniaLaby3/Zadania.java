package ZadaniaLaby3;

public class Zadania {
    public static void zad1(){}
    public static void zad2(){}
    public static void zad3(){}
    public static void zad4(){}
    public static void zad5(){}
}

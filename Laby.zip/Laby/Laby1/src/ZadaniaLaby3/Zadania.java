package ZadaniaLaby3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;




public class Zadania {
    protected static Scanner scan = new Scanner(System.in);


    public static void zad1() {
        System.out.println("Podaj ile elementów ma miec tablica: ");
        int n = scan.nextInt();
        System.out.println("podaj przedzial (a,b)\n a = ");
        int a = scan.nextInt();
        System.out.println("podaj b = ");
        int b = scan.nextInt();

        int[] tab = losowanie(a, b, n);
        if(tab!=null) {
            System.out.println("Elementy tablicy: ");
            int suma = 0;
            for (int item : tab) {
                System.out.println(item + " ");
                suma = suma + item;

            }
            System.out.println("suma tablicy= " + suma);
            System.out.println("srednia= " + (suma / tab.length));
        }else System.out.println("Tablica nie moze byc zerowa");


    }
    public static void zad2() {
        System.out.println("program wypisuje co drugi element zdefiniowanych przez mnie tablic");
        int[] tab1 = {1,2,3,4,5,6,7,8,9,10};
        int[] tab2 = {5,3,6,3,4,6,7,8,24,24,13,13,11};
        System.out.println("co drugi element 1 tablicy");
        for(int i=0; i< tab1.length;i+=2){
            System.out.println("tab["+i+"] = "+tab1[i]);
        }
        System.out.println("co drugi element 2 tablicy");
        for(int i=0; i< tab2.length;i+=2){
            System.out.println("tab["+i+"] = "+tab2[i]);
        }
    }
    public static void zad3() {
            String[] tab = {"rower","jabuszko","pralka","mieszakanie nr 117","bulwary"};

            for(String item:tab){
            System.out.println(item.toUpperCase()+" ");
        }

    }
    /* Napisz program, który pobierze od użytkownika pięć słów i zapisze je w tablicy. Następnie,
program powinien wypisać wszystkie słowa, od ostatniego do pierwszego, z literami
zapisanymi od końca do początku. Dla przykładu, dla podanych słów "Ala", "ma", "kota", "i",
"psa" program powinien wypisać: "asp", "i", "atok", "am", "alA".*/
    public static void zad4() {
      String[] zdanie = new String[5];

      for(int i=0;i<5;i++){
        System.out.println("Podaj element "+(i+1)+" tablicy : ");
        zdanie[i] = scan.next();

      }
for(String item:zdanie){
    System.out.print(item+" ");
}




    }
    public static void zad5() {}
    public static void zad6() {}
    public static void zad7() {}

    public static int[] losowanie(int a, int b, int ilosc) {
        if (a > b) {
            System.out.println("Poczatek przedzialu nie moze byc wiekszy od konca");
            return null;
        }
        if (ilosc < 0) {
            System.out.println("ilosc ele do wylosowania nize moze byc <0");
            return null;
        }
        Random rand = new Random();
        int[] val = new int[ilosc];
        for (int i = 0; i < val.length; i++) {
            val[i] = rand.nextInt(b - a + 1) + a;
        }
        return val;
    }
}

